-- Notice --

Please use this leaves texture if you are playing with "Fancy trees" disabled. Leaves will look much better.
Copy this texture into the "data" folder, replace the old one (you may want to backup it first).
The fancy leaves texture is here so you don't have to backup, don't remove it. :)
